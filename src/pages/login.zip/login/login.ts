import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,AlertController, LoadingController, Loading, MenuController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  loading: Loading;
  
  loginModel = { 
    username: '', 
    password: '' ,
    role_id : ''
  };
  kidCare: any = ''; 

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private auth: AuthServiceProvider,
    private alertCtrl: AlertController, 
    private loadingCtrl: LoadingController,
    public menuCtrl: MenuController
  ) {
    this.kidCare = 'Owner';
  }

/** Start Center Login Function */
  public centerLogin() {
    this.loginModel.role_id = '2';
    this.showLoading()
    this.auth.login(this.loginModel).subscribe(userStatus => {
      if (userStatus) {        

        this.navCtrl.setRoot('DashboardPage');
        this.menuCtrl.enable(false, 'parentAuthenticated');        
        this.menuCtrl.enable(true, 'centerAuthenticated');  
        
      } else {
        this.showError("Access Denied");
      }
    },
      error => {
        this.showError(error);
        console.log("Error pleas check !! => " + error.status); 
      });
  }
 /** End User Login Function */

 /** Start Center Login Function */
 public parentLogin() {
  this.loginModel.role_id = '3';
  this.showLoading()
  this.auth.login(this.loginModel).subscribe(userStatus => {
    if (userStatus) { 
      console.log(userStatus);  
      this.navCtrl.setRoot('DashboardPage');
      this.menuCtrl.enable(false, 'centerAuthenticated');
      
      this.menuCtrl.enable(true, 'parentAuthenticated');
      
    } else {
      this.showError("Access Denied");
    }
  },
    error => {
      this.showError(error);
      console.log("Error pleas check !! => " + error.status); 
    });
}
/** End User Login Function */


  /** Start - Loading page function */
  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'loading...',
      dismissOnPageChange: true
    });
    this.loading.present();
  }
 /** End - Loading page function */

 /** Start Show Error Alert function */
  showError(message) {
    this.loading.dismiss();
    let alert = this.alertCtrl.create({
      title: 'Fail',
      subTitle: message,
      buttons: ['OK']
    });
    alert.present();
  }
/** End Show Error Alert function */

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }
}
